import numpy as np
import random
import json
#чтение исходных данных из json файла
with open("data_file.json", "r") as read_file:
    data = json.load(read_file)

num_fram = int(data['num_frames'])
startSlot, endSlot = int(data['num_slots'][0]), int(data['num_slots'][1])

# число фреймов
frames=[]
for i in range(num_fram):
    frames.append({})

# функция для получения слотов для конкретного фрейма
def getSlots(num):
    slots = []
    z = 1
    for frame in range(int(num)):
        slots.append({})
    for slot in slots:
        slot.update({ "code" : "Слот"+str(z)+str(j), "name" : "Слот"+str(z)})
        z+=1
    return slots

# задаем информации по фреймам
j = 1
num_of_single_slots = 0 # число фреймом с одним слотом
num_slots = np.random.uniform(startSlot, endSlot, num_fram)
for frame in frames:
    frame.update({ "code" : "Фрейм"+str(j), "name" : "Фрейм"+str(j), "slots" : getSlots(num_slots[j-1])})
    if (int(num_slots[j-1]) == 1):
        num_of_single_slots += 1
    j+=1

# численное сравнение для парных сравнений
def EachHasNum(slotsF1, slotsF2):
    inf = {}
    for slotF1 in slotsF1:
        sF1 = {}
        for slotF2 in slotsF2:
            if (slotF1 != slotF2):
                n = random.randint(0, 9)
                if (n == 0):
                    n = round(random.triangular(0.1, 0.9), 1)
                sF1.update({slotF2['code'] : n})
            inf.update({slotF1['code']:sF1})
    return inf

# просто численное влияние
def EveryNum(slotF1, slotsF2):
    sF1 = {}
    for slotF2 in slotsF2:
            if (slotF1 != slotF2):
                n = random.randint(0, 9)
                if (n == 0):
                    n = round(random.triangular(0.1, 0.9), 1)
                sF1.update({slotF2['code'] : n})
    return sF1

# парное сравнение
def PairedComp(slotF1, slotsF2):
    sF1 = {}
    not_pos=[]
    for slotF2 in slotsF2:
        not_pos.append(slotF2)
    for slotF2 in slotsF2:
        if (slotF1 != slotF2):
            if (slotF2 in not_pos and len(not_pos)!=1):
                not_pos.remove(slotF2)
                sF1.update(EachHasNum([slotF2], not_pos))
            elif (len(not_pos) == 1):
                sF1.update({slotF2['code'] : {}})
    return sF1

# рандомно задаем влияние
def getInfluence(codeF1, codeF2, slotsF1, slotsF2):
    infl = {}
    for slotF1 in slotsF1:
        kind_inf = random.randint(1, 100)
        if (codeF1 == codeF2 and len(slotsF1)==1 and len(slotsF2)==1):
            sF1={}
            for slotF2 in slotsF2:
                sF1.update({slotF2['code'] : 1})
            infl.update({slotF1['code'] : sF1})
        elif (kind_inf % 2 == 0 or codeF1 == codeF2 or len(slotsF1)==1 or len(slotsF2)==1):
            con = EveryNum(slotF1, slotsF2);
            infl.update({slotF1['code'] : con})
        else:
            con = PairedComp(slotF1, slotsF2)
            infl.update({slotF1['code'] : con})
    return infl

# число связей
edges=[]
num_edges = np.random.uniform(1, num_fram**2) #число связей
for i in range(int(num_edges)):
    edges.append({})

fromto = {} # словарь уже существующих связей

# проверка не было ли такой пары для связи
def validCompare(fram1, fram2):
    connection = str(fram1['code']) + str(fram2['code'])
    global once
    if (fram1==fram2 and once): # для существования хотя бы одного влияние между слотами разных фреймов
        return False
    if (len(fromto)==0 or connection not in fromto):
        fromto.update({connection : True})
        once = False
        return True
    else:
        return False

once = False # для существования хотя бы одного влияние между слотами разных фреймов
if (num_fram>1): # если один фрейм, то все влияние будут внутренними
    once = True

# задаем связи
for edge in edges:
    ok = True
    while (ok):
        num_of_fram1 = random.randint(0, num_fram - 1)
        num_of_fram2 = random.randint(0, num_fram - 1)
        if (validCompare(frames[num_of_fram1], frames[num_of_fram2])):
            edge.update({"from": "Фрейм" + str(num_of_fram1 + 1), "to": "Фрейм" + str(num_of_fram2 + 1),
                         "influence": getInfluence(frames[num_of_fram2]['code'], frames[num_of_fram1]['code'],
                                                    frames[num_of_fram2]['slots'], frames[num_of_fram1]['slots'])})
            ok = False

data = {
    "frames": frames,
    "edges" : edges
}

# вывод на косоль в формате json
json_string = json.dumps(data, indent=2, ensure_ascii=False)
print(json_string)